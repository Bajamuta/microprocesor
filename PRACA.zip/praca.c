#include <REGX52.H>
#define LED_ON P0_0=0
#define LED_OFF P0_0=1

unsigned char bdata Key; //bitowo i bajtowo
sbit Key_1 = Key^1;
sbit Key_2 = Key^2;
sbit Key_3 = Key^3;

//0111 1111 => 0x7F
//1101 1111 => 0xDF
//1011 1111 => 0xBF
//1110 1111 => 0xEF

void mrugnij(unsigned char data ilosc)
{
	ilosc = 0;
}

void main(void)
{
	unsigned char code Tab[] = {0x7F, 0xDF, 0xBF, 0xEF};
	unsigned char code Tab2[] = {0x00, 0x00, 0x00, 0x00};
	unsigned char data ind;
	bit wykonaj = 1; //<- wymagana obsluga przycisku
	
	ind=0;
	
	for(;;)
	{
		P2 = Tab[ind];
		Key = P2; //<-
		if((Key_1 && Key_2 && Key_3) == 0) //jak 0 to wcisniety przycisk
		{
			if(wykonaj == 1)
			{
				P1 = Key; //tylko po to zeby podejrzec wartosc?
				//Tab2[ind] = Key; !!inaczej sczytac wartosc
				//if(Key == 0xE7) 
				//{
				//	LED_ON; 
				//}
				//if(Key == 0xBD) {LED_OFF;}
				wykonaj = 0; //koniec obslugi przycisku
			}
		}
		else
		{
			if(ind < 0x03) 
			{
				ind++;
			}
			else 
			{
				ind = 0;
			}
			wykonaj = 1;//przywroc obsluge przyciskow
		}
	}
	
}