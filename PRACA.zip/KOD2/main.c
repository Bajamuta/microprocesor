#include <REGX52.H>
#define LED_ON P3_7=0
#define LED_OFF P3_7=1

//EKRAN LCD

extern void LcdInit();
extern void LcdWelcome();
extern void Lcd_Cursor (char row, char column);
extern void Lcd_DisplayCharacter (char a_char);
extern void Lcd_DisplayString (char row, char column, char *string);
extern void Lcd_WriteControl (unsigned char LcdCommand);


unsigned char data Var1, Var2, Var3;
volatile unsigned char data kolumna;
unsigned char data Tab[] = {0x00, 0x00, 0x00, 0x00};
unsigned char data ind, start;

void Init(void)
  {
    P3_4=0;          // ustaw sie na odbior danych z portu szeregowego
    kolumna = 7;
		ind = 0;   
		start = 0;
    SCON=0x50;       // inicjowanie portu szeregowego
    RCAP2H=TH2=0xFF; // predkosc transmisji 1200b/sec przy CLK=1.3824MHz 
    RCAP2L=TL2=0xDC; // predkosc transmisji 1200b/sec przy CLK=1.3824MHz 
    T2CON=0x20;      // Timer 2 wyznacza predkosc transmisji przez Serial
    RI=TI=0;         // gaszenie flag odbiornika i nadajnika
    ES=1;            // wlacz odbieranie danych przez IRQ
    TR2=1;           // wlacz Timer 2
    EA=1;            // wlacz globalna maske przerwan
  }
	
	
	/*
	0 -> 0x30
	1 -> 0x31
	2 -> 0x32
	3 -> 0x33
	4 -> 0x34
	5 -> 0x35
	6 -> 0x36
	7 -> 0x37
	8 -> 0x38
	9 -> 0x39
	* -> 0x2A
	# -> 0x23
	*/
	
	
void wait(unsigned char t)
{
	unsigned char data x,y;
	for(x=0;x<t;x++)
		for(y=0;y<t;y++)
		{
			;
		}
}

void mrugnij(unsigned char i)
{
	unsigned char data x;
	for(x = 0; x < i; x++)
	{
		LED_ON;
		wait(50);
		LED_OFF;
		wait(30);
	}
}

void ISR_Serial(void) interrupt 4
 {
   if(RI==1)
    {
			LED_OFF;
			P1 = SBUF;
			if((SBUF != 0x23) && (SBUF != 0x2A) && (start == 0)) //nie *, nie # i nie pin
			{
				if(ind == 0) Lcd_DisplayString(3,1,"                "); //wyczysc kod gdy wpisujesz od poczatku
				
				Lcd_Cursor(3,kolumna);
				Tab[ind] = SBUF;
				Lcd_DisplayCharacter(Tab[ind]);
				P1 = Tab[ind]; //podglad co sie zapisalo
				if (kolumna<10){kolumna++;} else{kolumna=7;} //od 7 do 10 to 4 znaki!
				if(ind < 0x03){ind++;}
				else{ind=0;}
				//Send('&');
			}
			else
			{
				if(start != 1) //dopoki pin niepoprawny
				{
					if((Tab[0] == 0x30) && (Tab[1] == 0x30) && (Tab[2] == 0x30) && (Tab[3] == 0x30) ) 
					{
						start = 1;
						Lcd_DisplayString(3,7,"GOOD!");
						LED_ON;
						wait(200);
						ind = 0;
						Lcd_DisplayString(3,1,"                ");
						Lcd_DisplayString(1,1,"                ");
					Lcd_DisplayString(2,1,"                ");
					Lcd_DisplayString(4,1,"                ");
					}
					else
					{
						Lcd_DisplayString(3,7,"WRONG");
						ind = 0;
						mrugnij(3);
						Lcd_DisplayString(3,1,"                ");
						kolumna = 7;
					}
				}
				else
				{
					LED_ON;
					Lcd_Cursor(3,kolumna);
					Lcd_DisplayCharacter(SBUF);
					if (kolumna<11){kolumna++;} //else{kolumna=7;} //od 7 do 11 to 5 znak�w!
				 }
			}
			Lcd_WriteControl(0x0C);
			RI=0;
    }
 }

void main(void){
  LcdInit();            // Zainicjowanie rejestr�w uP
  LcdWelcome();         // wyswietlenie powitania
  Init();               // Zainicjowanie systemu przerwan
	
  while(1){
	;
	}
}