#include <REGX52.H>
#define LED_ON P0_0=0
#define LED_OFF P0_0=1

unsigned char bdata Key; //bitowo i bajtowo
sbit Key_1 = Key^1;
sbit Key_2 = Key^2;
sbit Key_3 = Key^3;

//KLAWIATURA

//0111 1111 => 0x7F
//1101 1111 => 0xDF
//1011 1111 => 0xBF
//1110 1111 => 0xEF

void wait(unsigned char t)
{
	unsigned char data x,y;
	for(x=0;x<t;x++)
		for(y=0;y<t;y++)
		{
			;
		}
}

unsigned char Szukaj(unsigned char Input)
 {
   unsigned char data Value=0;
   unsigned char data InpValue;
   
   InpValue=Input;
   //do kodu (skankod) zapisanego w InpValue przypisz okreslona liczbe lub znak
   //zwroc wyznaczona liczbe lub znak spowrotem
   if(InpValue==0x7B){Value = '0';} //0   
   if(InpValue==0xE7){Value = '1';} //1  
   if(InpValue==0xEB){Value = '2';} //2   
   if(InpValue==0xED){Value = '3';} //3   
   if(InpValue==0xD7){Value = '4';} //4  
   if(InpValue==0xDB){Value = '5';} //5   
   if(InpValue==0xDD){Value = '6';} //6   
   if(InpValue==0xB7){Value = '7';} //7   
   if(InpValue==0xBB){Value = '8';} //8   
   if(InpValue==0xBD){Value = '9';} //9  
   if(InpValue==0x77){Value = '*';} //*  
   if(InpValue==0x7D){Value = '#';} //#  
	 
   return Value;
 }

void Init(void)
 {
   P3_4=0;
   // tylko nadawanie
/*   
   SCON=0x40; 
   RCAP2L=TL2=0xDC;
   RCAP2H=TH2=0xFF;
   T2CON=0x14;
*/   
   //nadawanie i odbior
   SCON=0x50;
   RCAP2L=TL2=0xDC;
   RCAP2H=TH2=0xFF;
   TI=RI=0;
   ES=1;
   EA=1;
   T2CON=0x34;
 }
 
 void ISR_Serial(void) interrupt 4
 {
   if(RI==1) //odebrano znak
    {
      if(SBUF=='0'){LED_ON;}
      if(SBUF=='1'){LED_OFF;}
			if(SBUF=='#'){LED_ON; wait(200); LED_OFF; wait(50); LED_ON; wait(200); LED_OFF;}
			if(SBUF=='G'){P1 = '1';};
      RI=0;
    }
		else
		{
			LED_ON; wait(100); LED_OFF; wait(50); LED_ON; wait(100); LED_OFF;LED_ON; wait(50); LED_OFF;
		}
 }

void Send(unsigned char Value)
 {
   ES=0; //wylacz odbieranie
    P3_4=1; //wlacz nadawanie
     TI=0;
      SBUF=Value;
			//P1 = SBUF;
	 				LED_ON;
				wait(50);
				LED_OFF;
      while(TI==0){;}
     TI=0;  
    P3_4=0; //wylacz nadawanie
   ES=1; //wlacz odbieranie
 }


void Wykonaj(unsigned char Input)
 {
   unsigned char data InpValue;
   
   InpValue=Input;
   //wykonaj operacje z uwzglednieniem  warosci lub zanaku zapisanego w InpValue
   Send(InpValue);
	 P1 = InpValue;
 }


void main(void)
{
	unsigned char code Tab[] = {0x7F, 0xDF, 0xBF, 0xEF};
	unsigned char data Tab2[] = {0x00, 0x00, 0x00, 0x00};
	unsigned char data ind, ind2;
	bit En = 1;
	ind=0;
	ind2=0;
	Init(); //inicjacja konsoli
	
	for(;;)
	{
		P2 = Tab[ind];
		Key = P2;
		if((Key_1 && Key_2 && Key_3) == 0) //jak 0 to wcisniety przycisk
		{
			if(En == 1)
			{
				//P1 = Key; //tylko po to zeby podejrzec wartosc
				Tab2[ind2] = Key;			
				Wykonaj(Szukaj(Tab2[ind2]));
				if(ind2 < 0x03){ind2++;}
				else{ind2=0;}
				En = 0; //koniec obslugi przycisku
			}
		}
		else
		{
			if(ind < 0x03) 
			{
				ind++;
			}
			else 
			{
				ind = 0;
			}
			En = 1;//przywroc obsluge przyciskow
		}
	}
	
}