#include <REGX52.H>

#define NADAWANIE P3_4

volatile unsigned char xdata LEWY _at_ 0xFE00;
volatile unsigned char xdata PRAWY _at_ 0xFD00;
unsigned char code Koder[] = {0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D,0x07, 0x07F, 0x6F, 0xF6};

//DP gfedcba
// 0 0111111 => 0 na liczniku
// 0 0000110 => 1
// 0 1110110 => H 
// 1 1110110 => H 0xF6

volatile unsigned char data ind1, ind2, Tmp, indSBUF, start, i;
unsigned char data Tab[] = {0x00, 0x00, 0x00, 0x00};

void ISR_Timer1 (void) interrupt 3
{
	TR1 = 0; // wylacz timer
	LEWY = Koder[ind1]; // ustaw wartosc
	PRAWY = Koder[ind2];
	TH1 = 0xF0; // 0xF000 do 0xFFFF impuls�w zegara
	TL1 = 0x00;
	TR1 = 1; //wlacz timer
}

void Init (void)
{
	ind1 = ind2 = Tmp = indSBUF = 0x00;
	NADAWANIE = 0; // ustaw sie na odbior
	start = 0; //pin niepoprawny
	i = 99;
	TMOD = 0x10; // okienko Timer/Counter
	TH1 = 0xF0; // 0xF000 do 0xFFFF impuls�w zegara
	TL1 = 0x00;
	ET1 = 1;
	IT0 = 1; //aktywnosc na zbocze
	EX0 = 1;
	
	//INICJACJA PORTU SZEREGOWEGO
	SCON=0x50;       // inicjowanie portu szeregowego
  RCAP2H=TH2=0xFF; // predkosc transmisji 1200b/sec przy CLK=1.3824MHz 
  RCAP2L=TL2=0xDC; // predkosc transmisji 1200b/sec przy CLK=1.3824MHz 
  T2CON=0x20;      // Timer 2 wyznacza predkosc transmisji przez Serial
  RI=TI=0;         // gaszenie flag odbiornika i nadajnika
  ES=1;            // wlacz odbieranie danych przez IRQ
    
	
	EA = 1; // wlacz globalna maske przerwan
	TR1 = 1;
	TR2=1;           // wlacz Timer 2       
}

void ISR_Serial(void) interrupt 4
{
	if(RI==1)
  {
		P1 = SBUF;
		//if(SBUF=='*')
		//{
		//	ind1=ind2=0x00;
		//}
		//if(SBUF=='2')
		//{
	//	ind1=0x06;
		//}
		//if(SBUF=='3')
		//{
		//	Tmp = ind2;
		//	ind2 = ind1;
		//	ind1 = Tmp;
		//}
		if((SBUF != 0x23) && (SBUF != 0x2A) && (start == 0)) //spr czy nie * i nie # i nie pin
		{
			Tab[indSBUF] = SBUF;
		}
		else
		{
			if(start == 0) //dopoki pin niepoprawny
			{
				if((Tab[0] == 0x30) && (Tab[1] == 0x30) && (Tab[2] == 0x30) && (Tab[3] == 0x30) ) 
				{
					//IE0 = 1;
					start = 1;
				}
				else
				{
					//ind1=ind2=0x00; //zeruj licznik
				}
			}
			else //pin poprawny
			{
				if(SBUF == 'x')
				{
					IE0 = 1;
				}

				if(SBUF == '*')
				{
					ind1 = 0x00;
					ind2 = 0x00;
				}
			}
		}
		if(indSBUF < 0x03){indSBUF++;}
		else{indSBUF=0x00;}
		
		RI=0;
	}
}


void ISR_INT0 (void) interrupt 0
{
	ind2++;
	if(ind2 > 0x09)
	{
		ind2 = 0x00;
		ind1++;
		if(ind1 > 0x09)
		{
			ind1 = 0x00;
		}
	}	
}

void main (void)
{
	Init();
	for(;;)
	{
		;
	}
}
