#include <REGX52.H>

#define IN1 P2_1
#define IN2 P2_2
#define EN1 P2_3
#define Max 0xFF

volatile unsigned char Nastawa;
volatile unsigned char Suwak;

unsigned char data Tab[] = {0x00, 0x00, 0x00, 0x00};
unsigned char data ind, start, i;


void Setup(void)
{
	ind = 0;
	i = 99;
	start = 0; //jak 0 to zatrzymaj
	Nastawa = 0x80;    //0x00 do 0xFF
	Suwak = 0x00; // 0x00 do Nastawa (wtedy = 1) potem do Max (wtedy = 0)
	TMOD = 0x20; // 8 bitowy autoreload
	TH1=TL1=0x80; //maksymany okres czasu na pojedynczy impuls
	ET1=1;   //Timer1 IRQ wlaczone
	IN1 = 1;
	IN2 = 1;
	EN1 = 0;
	P3_4=0; //ustaw sie na odbior z portu szeregowego
	  SCON=0x50;       // inicjowanie portu szeregowego
    RCAP2H=TH2=0xFF; // predkosc transmisji 1200b/sec przy CLK=1.3824MHz 
    RCAP2L=TL2=0xDC; // predkosc transmisji 1200b/sec przy CLK=1.3824MHz 
    T2CON=0x30;      // Timer 2 wyznacza predkosc transmisji przez Serial
    RI=TI=0;         // gaszenie flag odbiornika i nadajnika
    ES=1;            // wlacz odbieranie danych przez IRQ
    EA=1;            // wlacz globalna maske przerwan
	TR2=1;           // wlacz Timer 2 (serial)
	TR1 = 1; //wlacz timer 1 (silnik)
}

void Send(unsigned char Value)
 {
   ES=0; //wylacz odbieranie
	 P3_4 = 1; //ustaw sie na nadawanie
	 TI = 0;
	 SBUF = Value;
	 while(TI==0){;}
	 TI=0;
	 P3_4=0;
	 ES=1;
 }
 
 void wait(unsigned char t)
{
	unsigned char data x,y;
	for(x=0;x<t;x++)
		for(y=0;y<t;y++)
		{
			;
		}
}

void ISR_Serial(void) interrupt 4
 {
   if(RI==1)
    {
			P1 = SBUF;
			if((SBUF != 0x23) && (SBUF != 0x2A) && (start == 0)) // gdy nie * lub # i nie pin
			{
					Tab[ind] = SBUF;
				//if(ind == 0) {
					
				//}
				if(ind < 0x03){ind++;}
				else{ind=0;}
			}
			else
			{
				if(start != 1) //dopoki pin niepoprawny
				{
					if((Tab[0] == 0x30) && (Tab[1] == 0x30) && (Tab[2] == 0x30) && (Tab[3] == 0x30) ) //pin poprawny
					{
						start = 1;
						wait(50);
						IN1 = 1; //w prawo
						IN2 = 0;
						wait(200);
						Send('G');
						wait(150);
						Send('O');
						wait(100);
						Send('!');
						wait(100);
						Send('!');
						wait(100);
						Send('!');
						ind = 0;
					}
					else
					{
					}
				}
				else //pin poprawny
				{
					//ZATRZYMAJ
					if(SBUF == '*')
					{
						IN1 = 1;
						IN2 = 1;
					}
					
					//szybciej
					if(SBUF == '9')
					{
						if(Nastawa < Max - 10) 
						{
							Nastawa = Nastawa + 10;
						}
						else
						{
							Nastawa = Max;
						}
					}
					
					//WOLNIEJ
					if(SBUF == '8') //wolniej
					{
						if(Nastawa > 10) 
						{
							Nastawa = Nastawa - 10;
						}
						else
						{
							Nastawa = 0;
						}
					}
					
					//ZMIANA KIERUNKU
					if(SBUF == '#')
					{
						if(IN1 == 1){ IN1 = 0;}
						else { IN1 = 1;}
						if(IN2 == 1){ IN2 = 0;}
						else { IN2 = 1;}
					}
					
				}
			}
			/*if(SBUF == '&')
			{
				IN1 = 1; // zatrzymaj
				IN2 = 1;
			}
			if(SBUF == '#')
			{
				wait(50);
				IN1 = 1; //w prawo
				IN2 = 0;
				wait(250);
				P1='0';
				Send('P');
			}
			if(SBUF == '4')
			{
				IN1 = 0;
				IN2 = 1;
				wait(200);
				P1='9';
				Send('L');
			}*/
			/*if(SBUF == '4')
			{
				IN1 = 0;
				IN2 = 1;
				Send('L');
			}
			if(SBUF == '6')
			{
				IN1 = 1;
				IN2 = 0;
				Send('P');
			}
			if(SBUF == '2') //szybciej
			{
				if(Nastawa < Max - 10) 
				{
					Nastawa = Nastawa + 10;
				}
				else
				{
					Nastawa = Max;
				}
				Send('U');
			}
			if(SBUF == '8') //wolniej
			{
				if(Nastawa > 10) 
				{
					Nastawa = Nastawa - 10;
				}
				else
				{
					Nastawa = 0;
				}
				Send('D');
			}
			if(SBUF == '#')
			{
				IN1 = 1;
				IN2 = 1;
				Send('S');
			}*/
			
      RI=0;
    }
 }
 
 void ISR_Timer1 (void) interrupt 3
 {
	 Suwak++;
	 if(Suwak>=Nastawa)
	 {
		 if(Nastawa != Max) { EN1=0;}
		 else { EN1 = 1; }
	 }
	 if(Suwak == Max)
	 {
		 Suwak = 0x00;
		 if(Nastawa != 0) { EN1 = 1; } //zeby nie szarpac kluczem
		 else { EN1 = 0;}
	 }
 }

void main(void)
{
	Setup();
	while(1){
		if((start == 1) && (IN1 != 1) || (IN2 != 1) )
		{
			Send('x');
			wait(60);
		}
	}
}